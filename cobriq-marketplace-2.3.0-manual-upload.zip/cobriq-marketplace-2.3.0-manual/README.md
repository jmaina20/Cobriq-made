# Cobriq Marketplace — BriquetteLink Kenya 2.3.0

Kenya-wide WordPress marketplace for briquettes. Customers select a town rather than sharing GPS coordinates. Suppliers apply, get approved, list towns, products, pricing and stock, and manage fulfillment.

## 2.3 marketplace layer
- Public marketplace/catalog with town filtering and product/supplier search.
- Public supplier storefronts showing live active stock and prices.
- Direct order links preselect town/product on the main order form.
- Existing supplier portal, order tracking, fulfillment workflow and analytics retained.
- Optional WhatsApp integration remains disabled until configured.
- Payments/M-Pesa are intentionally excluded.

## WordPress installation
1. Install `plugin/briquettelink-core` as a WordPress plugin.
2. Install `theme/briquettelink-kenya` as the active theme.
3. Activate the plugin first; it creates/updates marketplace tables and pages.
4. Activate the theme.

Generated pages include `/marketplace/`, `/supplier-storefront/`, `/supplier-portal/`, `/track-order/`, and `/town-marketplace/`.

## Data model
`locations`, `suppliers`, `supplier_locations`, `products`, `inventory`, `orders`, `order_items`, `order_status_history`, and `webhook_logs`.

## Privacy model
No customer GPS coordinates are collected or required. The customer provides name, phone/WhatsApp, town, product, quantity and optional delivery notes.
