<?php
if (!defined('ABSPATH')) exit;
class BriquetteLink_Analytics {
 public static function init(){add_action('admin_menu',function(){add_submenu_page('briquettelink','Analytics','Analytics','manage_options','briquettelink-analytics',array(__CLASS__,'admin_page'));});}
 public static function summary($supplier_id=0,$days=30){
  global $wpdb; $t=BriquetteLink_Database::tables(); $days=max(1,min(365,(int)$days));
  $where="created_at >= %s"; $params=array(wp_date('Y-m-d H:i:s',current_time('timestamp')-($days*DAY_IN_SECONDS)));
  if($supplier_id){$where.=' AND supplier_id=%d';$params[]=(int)$supplier_id;}
  $base=$wpdb->get_row($wpdb->prepare("SELECT COUNT(*) orders, COALESCE(SUM(total),0) order_value FROM {$t['orders']} WHERE $where",$params),ARRAY_A);
  $completed_params=$params; $completed_params[]='completed';
  $completed=$wpdb->get_row($wpdb->prepare("SELECT COUNT(*) orders, COALESCE(SUM(total),0) order_value FROM {$t['orders']} WHERE $where AND status=%s",$completed_params),ARRAY_A);
  $cancel_params=$params; $cancel_params[]='cancelled';
  $cancelled=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['orders']} WHERE $where AND status=%s",$cancel_params));
  $status=$wpdb->get_results($wpdb->prepare("SELECT status,COUNT(*) total FROM {$t['orders']} WHERE $where GROUP BY status ORDER BY total DESC",$params),ARRAY_A);
  $top_sql="SELECT p.name,SUM(oi.quantity) quantity,COALESCE(SUM(oi.line_total),0) value FROM {$t['order_items']} oi JOIN {$t['products']} p ON p.id=oi.product_id JOIN {$t['orders']} o ON o.id=oi.order_id WHERE o.created_at >= %s"; $top_params=array($params[0]);
  if($supplier_id){$top_sql.=' AND o.supplier_id=%d';$top_params[]=(int)$supplier_id;}
  $top=$wpdb->get_results($wpdb->prepare($top_sql.' GROUP BY oi.product_id ORDER BY quantity DESC LIMIT 5',$top_params),ARRAY_A);
  return array('days'=>$days,'orders'=>(int)$base['orders'],'order_value'=>(float)$base['order_value'],'completed_orders'=>(int)$completed['orders'],'completed_value'=>(float)$completed['order_value'],'cancelled_orders'=>$cancelled,'statuses'=>$status,'top_products'=>$top);
 }
 public static function admin_page(){
  if(!current_user_can('manage_options')) return;
  $days=isset($_GET['days'])?max(7,min(365,absint($_GET['days']))):30; $data=self::summary(0,$days);
  echo '<div class="wrap"><h1>BriquetteLink Analytics</h1><p>Operational marketplace reporting; values represent order totals, not processed payments.</p><p><a class="button" href="'.esc_url(add_query_arg('days',7)).'">7 days</a> <a class="button" href="'.esc_url(add_query_arg('days',30)).'">30 days</a> <a class="button" href="'.esc_url(add_query_arg('days',90)).'">90 days</a></p>';
  echo '<div style="display:flex;gap:15px;flex-wrap:wrap">'; foreach(array('Orders'=>$data['orders'],'Order value'=>'KSh '.number_format_i18n($data['order_value'],2),'Completed'=>$data['completed_orders'],'Completed value'=>'KSh '.number_format_i18n($data['completed_value'],2),'Cancelled'=>$data['cancelled_orders']) as $k=>$v) echo '<div class="card" style="padding:18px;min-width:150px"><span>'.$k.'</span><br><strong style="font-size:22px">'.$v.'</strong></div>'; echo '</div>';
  echo '<h2>Status breakdown</h2><table class="widefat striped"><thead><tr><th>Status</th><th>Orders</th></tr></thead><tbody>'; foreach($data['statuses'] as $r) echo '<tr><td>'.esc_html(ucfirst($r['status'])).'</td><td>'.esc_html($r['total']).'</td></tr>'; echo '</tbody></table>';
  echo '<h2>Top products</h2><table class="widefat striped"><thead><tr><th>Product</th><th>Quantity</th><th>Order value</th></tr></thead><tbody>'; foreach($data['top_products'] as $r) echo '<tr><td>'.esc_html($r['name']).'</td><td>'.esc_html(number_format_i18n((float)$r['quantity'],2)).'</td><td>KSh '.esc_html(number_format_i18n((float)$r['value'],2)).'</td></tr>'; if(!$data['top_products']) echo '<tr><td colspan="3">No product data.</td></tr>'; echo '</tbody></table></div>';
 }
}
