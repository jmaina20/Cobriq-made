<?php
if (!defined('ABSPATH')) exit;

class BriquetteLink_Customer {
 public static function init(){
  add_shortcode('briquettelink_order_tracking',array(__CLASS__,'tracking_shortcode'));
  add_shortcode('briquettelink_town_marketplace',array(__CLASS__,'town_marketplace_shortcode'));
 }

 private static function find_order($number,$phone){
  global $wpdb;
  $t=BriquetteLink_Database::tables();
  $number=sanitize_text_field($number);
  $phone=preg_replace('/\D+/','',$phone);
  if(!$number||strlen($phone)<7)return null;
  $rows=$wpdb->get_results($wpdb->prepare("SELECT o.*,l.town_name,l.county_name FROM {$t['orders']} o JOIN {$t['locations']} l ON l.id=o.location_id WHERE o.order_number=%s ORDER BY o.id DESC LIMIT 1",$number),ARRAY_A);
  if(!$rows)return null;
  $order=$rows[0];
  if(preg_replace('/\D+/','',$order['customer_phone'])!==$phone && preg_replace('/\D+/','',$order['customer_whatsapp'])!==$phone)return null;
  return $order;
 }

 public static function tracking_data($number,$phone){
  global $wpdb;
  $t=BriquetteLink_Database::tables();
  $order=self::find_order($number,$phone);
  if(!$order)return null;
  $items=$wpdb->get_results($wpdb->prepare("SELECT oi.*,p.name,p.unit FROM {$t['order_items']} oi JOIN {$t['products']} p ON p.id=oi.product_id WHERE oi.order_id=%d ORDER BY oi.id",$order['id']),ARRAY_A);
  $history=$wpdb->get_results($wpdb->prepare("SELECT status,note,created_at FROM {$t['order_status_history']} WHERE order_id=%d ORDER BY id ASC",$order['id']),ARRAY_A);
  $supplier=null;
  if($order['supplier_id'])$supplier=$wpdb->get_row($wpdb->prepare("SELECT business_name,phone,whatsapp FROM {$t['suppliers']} WHERE id=%d",$order['supplier_id']),ARRAY_A);
  return array('order_number'=>$order['order_number'],'status'=>$order['status'],'customer_name'=>$order['customer_name'],'town'=>$order['town_name'],'county'=>$order['county_name'],'subtotal'=>(float)$order['subtotal'],'delivery_fee'=>(float)$order['delivery_fee'],'total'=>(float)$order['total'],'created_at'=>$order['created_at'],'updated_at'=>$order['updated_at'],'notes'=>$order['notes'],'fulfillment_method'=>$order['fulfillment_method'],'delivery_notes'=>$order['delivery_notes'],'eta_date'=>$order['eta_date'],'tracking_reference'=>$order['tracking_reference'],'supplier'=>$supplier,'items'=>$items,'history'=>$history);
 }

 public static function tracking_shortcode(){
  $html='<div class="bl-portal bl-customer-portal"><h2>Track your order</h2><p>Enter your order number and the phone/WhatsApp number used when you placed the order.</p><form id="bl-track-form" class="bl-grid-form" style="grid-template-columns:1fr 1fr auto"><label>Order number<input name="order_number" placeholder="BL-260927-1234" required></label><label>Phone / WhatsApp<input name="phone" required></label><button class="bl-btn" type="submit">Track order</button></form><div id="bl-track-result" class="notice" style="display:none"></div></div>';
  return $html;
 }

 public static function town_marketplace_shortcode($atts=array()){
  $atts=shortcode_atts(array('town_id'=>0),$atts,'briquettelink_town_marketplace');
  $town_id=absint($atts['town_id']);
  if(!$town_id && isset($_GET['town_id']))$town_id=absint($_GET['town_id']);
  $towns=BriquetteLink_Matcher::towns();
  $selected=null;
  foreach($towns as $town)if((int)$town['id']===$town_id)$selected=$town;
  ob_start();
  ?>
  <div class="bl-portal bl-town-marketplace">
   <div class="bl-portal-head"><div><h2>Find briquettes by town</h2><p>Choose a town to see approved suppliers serving that area.</p></div></div>
   <form method="get" class="bl-grid-form" style="grid-template-columns:1fr auto"><label>Town in Kenya<select name="town_id" required><option value="">Select town</option><?php foreach($towns as $town): ?><option value="<?php echo esc_attr($town['id']); ?>" <?php selected($town_id,$town['id']); ?>><?php echo esc_html($town['town_name'].' — '.$town['county_name']); ?></option><?php endforeach; ?></select></label><button class="bl-btn">View suppliers</button></form>
   <?php if($selected):
    global $wpdb;$t=BriquetteLink_Database::tables();
    $rows=$wpdb->get_results($wpdb->prepare("SELECT s.id,s.business_name,s.contact_name,s.phone,s.whatsapp,s.description,p.name product_name,p.unit,i.price_per_unit,i.stock_quantity,i.minimum_quantity FROM {$t['supplier_locations']} sl JOIN {$t['suppliers']} s ON s.id=sl.supplier_id JOIN {$t['inventory']} i ON i.supplier_id=s.id JOIN {$t['products']} p ON p.id=i.product_id WHERE sl.location_id=%d AND s.approval_status='approved' AND s.active=1 AND i.active=1 AND i.stock_quantity>0 ORDER BY s.business_name,p.name",$town_id),ARRAY_A);
    if(!$rows){echo '<div class="bl-notice">No approved supplier currently has active stock listed for '.esc_html($selected['town_name']).'.</div>';}else{ $grouped=array(); foreach($rows as $row){if(!isset($grouped[$row['id']]))$grouped[$row['id']]=array('supplier'=>$row,'products'=>array());$grouped[$row['id']]['products'][]=$row;} ?>
     <h3>Suppliers serving <?php echo esc_html($selected['town_name']); ?></h3><div class="supplier-list">
     <?php foreach($grouped as $group): $s=$group['supplier']; ?><article class="supplier"><div class="supplier-head"><div class="logo-circle">🌿</div><div><h3><?php echo esc_html($s['business_name']); ?></h3><div class="meta"><?php echo esc_html($selected['town_name'].', '.$selected['county_name']); ?></div></div></div><p class="meta"><?php echo esc_html($s['description']); ?></p><table class="bl-table"><thead><tr><th>Product</th><th>Price</th><th>Stock</th></tr></thead><tbody><?php foreach($group['products'] as $p): ?><tr><td><?php echo esc_html($p['product_name']); ?></td><td>KSh <?php echo esc_html(number_format_i18n((float)$p['price_per_unit'],2)); ?>/<?php echo esc_html($p['unit']); ?></td><td><?php echo esc_html(number_format_i18n((float)$p['stock_quantity'],2)); ?></td></tr><?php endforeach; ?></tbody></table><a class="bl-btn" href="<?php echo esc_url(home_url('/#orders')); ?>">Order from marketplace</a></article><?php endforeach; ?></div>
    <?php }
   endif; ?>
  </div>
  <?php
  return ob_get_clean();
 }
}
