BriquetteLink Core 2.3.0

Next production layer: customer order tracking, town marketplace directory, safer order stock reservation/cancellation, admin order queue, supplier approval email notifications, optional WhatsApp status notifications, and public order-request rate limiting. M-Pesa is not included. No customer GPS coordinates are collected.

Shortcodes:
- [briquettelink_supplier_portal]
- [briquettelink_order_tracking]
- [briquettelink_town_marketplace]


2.3.0 additions:
- Supplier operational dashboard with 30-day order metrics.
- Fulfillment fields: pickup/delivery, ETA date, tracking reference and notes.
- Admin analytics dashboard.
- Supplier and customer operational email notifications.
- Customer tracking exposes fulfillment progress.
- No GPS coordinates and no M-Pesa/payment integration.
