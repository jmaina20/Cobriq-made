<?php
if (!defined('ABSPATH')) exit;
class BriquetteLink_REST {
 public static function init(){add_action('rest_api_init',array(__CLASS__,'routes'));}
 public static function routes(){
  register_rest_route('briquettelink/v1','/towns',array('methods'=>'GET','callback'=>array(__CLASS__,'towns'),'permission_callback'=>'__return_true'));
  register_rest_route('briquettelink/v1','/products',array('methods'=>'GET','callback'=>array(__CLASS__,'products'),'permission_callback'=>'__return_true'));
  register_rest_route('briquettelink/v1','/match',array('methods'=>'GET','callback'=>array(__CLASS__,'match'),'permission_callback'=>'__return_true','args'=>array('town_id'=>array('required'=>true,'validate_callback'=>'is_numeric'),'product_id'=>array('required'=>true,'validate_callback'=>'is_numeric'),'quantity'=>array('required'=>true,'validate_callback'=>'is_numeric'))));
  register_rest_route('briquettelink/v1','/orders',array('methods'=>'POST','callback'=>array(__CLASS__,'create_order'),'permission_callback'=>'__return_true'));
  register_rest_route('briquettelink/v1','/orders/track',array('methods'=>'GET','callback'=>array(__CLASS__,'track_order'),'permission_callback'=>'__return_true','args'=>array('order_number'=>array('required'=>true),'phone'=>array('required'=>true))));
 }
 public static function towns(){return rest_ensure_response(BriquetteLink_Matcher::towns());}
 public static function products(){global $wpdb;$t=BriquetteLink_Database::tables();return rest_ensure_response($wpdb->get_results("SELECT id,name,slug,description,unit FROM {$t['products']} WHERE active=1 ORDER BY name",ARRAY_A));}
 public static function match($r){$town=absint($r['town_id']);$pid=absint($r['product_id']);$qty=max(.01,(float)$r['quantity']);return rest_ensure_response(BriquetteLink_Matcher::find_by_town($town,$pid,$qty,10));}
 public static function track_order($r){$number=sanitize_text_field($r['order_number']);$phone=sanitize_text_field($r['phone']);$data=BriquetteLink_Customer::tracking_data($number,$phone);if(!$data)return new WP_Error('order_not_found','Order not found. Check the order number and phone/WhatsApp number.',array('status'=>404));return rest_ensure_response($data);}
 public static function create_order($r){
  global $wpdb;$t=BriquetteLink_Database::tables();$d=$r->get_json_params();
  if(!empty($d['website']))return new WP_Error('invalid_request','Invalid order request.',array('status'=>400));$rate_key='bl_order_rate_'.md5((string)($_SERVER['REMOTE_ADDR']??'unknown'));$rate=(int)get_transient($rate_key);if($rate>=12)return new WP_Error('rate_limited','Too many order requests. Please wait a few minutes and try again.',array('status'=>429));set_transient($rate_key,$rate+1,10*MINUTE_IN_SECONDS);$name=sanitize_text_field($d['customer_name']??'');$phone=sanitize_text_field($d['customer_phone']??'');$town=absint($d['town_id']??0);$pid=absint($d['product_id']??0);$qty=max(0,(float)($d['quantity']??0));$notes=sanitize_textarea_field($d['notes']??'');$fulfillment=in_array($d['fulfillment_method']??'delivery',array('delivery','pickup'),true)?$d['fulfillment_method']:'delivery';
  if(!$name||!$phone||!$town||!$pid||$qty<=0)return new WP_Error('invalid_order','Please provide name, phone, town, product and quantity.',array('status'=>400));
  $town_exists=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['locations']} WHERE id=%d AND active=1",$town));
  $product=$wpdb->get_row($wpdb->prepare("SELECT id,name,unit FROM {$t['products']} WHERE id=%d AND active=1",$pid),ARRAY_A);
  if(!$town_exists||!$product)return new WP_Error('invalid_selection','The selected town or product is not available.',array('status'=>400));
  $matches=BriquetteLink_Matcher::find_by_town($town,$pid,$qty,1);$supplier_id=$matches?absint($matches[0]['id']):0;$price=$matches?(float)$matches[0]['price_per_unit']:0;$total=$price*$qty;$number='BL-'.wp_date('ymd').'-'.wp_rand(1000,9999);$now=current_time('mysql');
  $wpdb->query('START TRANSACTION');
  $reserved=false;
  if($supplier_id){$reserved=(bool)$wpdb->query($wpdb->prepare("UPDATE {$t['inventory']} SET stock_quantity=stock_quantity-%f,updated_at=%s WHERE supplier_id=%d AND product_id=%d AND active=1 AND stock_quantity >= %f",$qty,$now,$supplier_id,$pid,$qty));if(!$reserved)$supplier_id=0;}
  $status=$supplier_id?'pending':'unmatched';
  $ok=$wpdb->insert($t['orders'],array('order_number'=>$number,'customer_name'=>$name,'customer_phone'=>$phone,'customer_whatsapp'=>sanitize_text_field($d['customer_whatsapp']??$phone),'location_id'=>$town,'supplier_id'=>$supplier_id?:null,'subtotal'=>$total,'delivery_fee'=>0,'total'=>$total,'status'=>$status,'fulfillment_method'=>$fulfillment,'delivery_notes'=>'','eta_date'=>null,'tracking_reference'=>'','stock_released'=>0,'source'=>sanitize_key($d['source']??'web'),'notes'=>$notes,'created_at'=>$now,'updated_at'=>$now),array('%s','%s','%s','%s','%d','%d','%f','%f','%f','%s','%s','%s','%s','%s','%d','%s','%s','%s','%s'));
  if(!$ok){$wpdb->query('ROLLBACK');return new WP_Error('order_failed','Could not create the order.',array('status'=>500));}
  $oid=$wpdb->insert_id;$wpdb->insert($t['order_items'],array('order_id'=>$oid,'product_id'=>$pid,'quantity'=>$qty,'unit_price'=>$price,'line_total'=>$total),array('%d','%d','%f','%f','%f'));
  $wpdb->insert($t['order_status_history'],array('order_id'=>$oid,'status'=>$status,'changed_by'=>get_current_user_id()?:null,'note'=>'Order created','created_at'=>$now));
  $wpdb->query('COMMIT');
  do_action('briquettelink_order_created',$oid,$supplier_id);
  return rest_ensure_response(array('success'=>true,'order_number'=>$number,'supplier_id'=>$supplier_id,'total'=>$total,'status'=>$status,'message'=>$supplier_id?'Order received and matched to a supplier in your town. Save your order number to track it.':'Order received; no matching supplier with enough stock was found yet. Save your order number to track it.'));
 }
}
