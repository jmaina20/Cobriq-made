<?php
if (!defined('ABSPATH')) exit;

class BriquetteLink_Marketplace {
 public static function init(){
  add_shortcode('briquettelink_marketplace',array(__CLASS__,'marketplace_shortcode'));
  add_shortcode('briquettelink_supplier_storefront',array(__CLASS__,'storefront_shortcode'));
 }

 private static function catalog($town_id=0,$supplier_id=0,$search=''){
  global $wpdb; $t=BriquetteLink_Database::tables();
  $where=array("s.approval_status='approved'","s.active=1","i.active=1","i.stock_quantity>0","p.active=1"); $args=array();
  if($town_id){$where[]='sl.location_id=%d';$args[]=$town_id;}
  if($supplier_id){$where[]='s.id=%d';$args[]=$supplier_id;}
  if($search){$like='%'.$wpdb->esc_like($search).'%';$where[]='(p.name LIKE %s OR p.description LIKE %s OR s.business_name LIKE %s)';$args[]=$like;$args[]=$like;$args[]=$like;}
  $sql="SELECT s.id supplier_id,s.business_name,s.phone,s.whatsapp,s.description,p.id product_id,p.name product_name,p.description product_description,p.unit,i.price_per_unit,i.stock_quantity,i.minimum_quantity,l.id town_id,l.town_name,l.county_name FROM {$t['suppliers']} s JOIN {$t['supplier_locations']} sl ON sl.supplier_id=s.id JOIN {$t['locations']} l ON l.id=sl.location_id JOIN {$t['inventory']} i ON i.supplier_id=s.id JOIN {$t['products']} p ON p.id=i.product_id WHERE ".implode(' AND ',$where)." ORDER BY s.business_name,p.name";
  return $args?$wpdb->get_results($wpdb->prepare($sql,$args),ARRAY_A):$wpdb->get_results($sql,ARRAY_A);
 }

 public static function marketplace_shortcode($atts=array()){
  $atts=shortcode_atts(array('town_id'=>0),$atts,'briquettelink_marketplace');
  $town_id=absint($_GET['town_id']??$atts['town_id']); $search=sanitize_text_field(wp_unslash($_GET['q']??''));
  $towns=BriquetteLink_Matcher::towns(); $rows=self::catalog($town_id,0,$search); $groups=array();
  foreach($rows as $r){$sid=(int)$r['supplier_id']; if(!isset($groups[$sid]))$groups[$sid]=array('supplier'=>$r,'products'=>array()); $groups[$sid]['products'][]=$r;}
  ob_start(); ?>
  <div class="bl-portal bl-marketplace">
   <div class="bl-portal-head"><div><h2>Kenya Briquette Marketplace</h2><p>Compare available briquettes from approved suppliers serving your town.</p></div><a class="bl-btn secondary" href="<?php echo esc_url(home_url('/supplier-portal/')); ?>">Join as supplier</a></div>
   <form method="get" class="bl-market-filters">
    <label>Town in Kenya<select name="town_id"><option value="">All towns</option><?php foreach($towns as $town): ?><option value="<?php echo esc_attr($town['id']); ?>" <?php selected($town_id,$town['id']); ?>><?php echo esc_html($town['town_name'].' — '.$town['county_name']); ?></option><?php endforeach; ?></select></label>
    <label>Search products or suppliers<input name="q" value="<?php echo esc_attr($search); ?>" placeholder="e.g. sawdust, Nairobi supplier"></label>
    <button class="bl-btn">Browse marketplace</button>
   </form>
   <?php if($town_id): foreach($towns as $town): if((int)$town['id']===$town_id): ?><div class="bl-notice">Showing suppliers with available stock serving <strong><?php echo esc_html($town['town_name'].', '.$town['county_name']); ?></strong>.</div><?php endif; endforeach; endif; ?>
   <?php if(!$groups): ?><div class="bl-notice">No matching in-stock products were found. Try another town or search term.</div><?php else: ?>
    <div class="bl-market-grid">
    <?php foreach($groups as $group): $s=$group['supplier']; ?>
     <article class="bl-store-card">
      <div class="bl-store-head"><div class="logo-circle">🌿</div><div><h3><?php echo esc_html($s['business_name']); ?></h3><p class="meta">Serving <?php echo esc_html($s['town_name'].', '.$s['county_name']); ?></p></div></div>
      <?php if($s['description']): ?><p class="meta"><?php echo esc_html(wp_trim_words($s['description'],24)); ?></p><?php endif; ?>
      <div class="bl-catalog-list">
       <?php foreach($group['products'] as $p): ?><div class="bl-catalog-item"><div><strong><?php echo esc_html($p['product_name']); ?></strong><div class="meta">Stock <?php echo esc_html(number_format_i18n((float)$p['stock_quantity'],2).' '.$p['unit']); ?> · Min <?php echo esc_html(number_format_i18n((float)$p['minimum_quantity'],2)); ?></div></div><div class="bl-price">KSh <?php echo esc_html(number_format_i18n((float)$p['price_per_unit'],2)); ?><small>/<?php echo esc_html($p['unit']); ?></small></div><a class="bl-btn small" href="<?php echo esc_url(add_query_arg(array('supplier_id'=>$s['supplier_id'],'product_id'=>$p['product_id'],'town_id'=>$p['town_id']),home_url('/'))); ?>#orders">Order</a></div><?php endforeach; ?>
      </div>
      <a class="bl-btn secondary" href="<?php echo esc_url(add_query_arg('supplier_id',$s['supplier_id'],home_url('/supplier-storefront/'))); ?>">View supplier storefront</a>
     </article>
    <?php endforeach; ?></div>
   <?php endif; ?>
  </div><?php return ob_get_clean();
 }

 public static function storefront_shortcode($atts=array()){
  $id=absint($_GET['supplier_id']??($atts['supplier_id']??0));
  if(!$id)return '<div class="bl-notice">Choose a supplier from the marketplace to view their storefront.</div>';
  $rows=self::catalog(0,$id,''); if(!$rows)return '<div class="bl-notice">This supplier has no active in-stock products listed right now.</div>';
  $s=$rows[0]; $towns=array(); foreach($rows as $r){$towns[$r['town_id']]=$r['town_name'].' — '.$r['county_name'];}
  ob_start(); ?><div class="bl-portal bl-storefront"><div class="bl-store-hero"><div class="logo-circle">🌿</div><div><h2><?php echo esc_html($s['business_name']); ?></h2><p><?php echo esc_html($s['description']?:'Approved briquette supplier on the Kenya marketplace.'); ?></p><div class="meta">Serving <?php echo esc_html(implode(', ',array_values($towns))); ?></div></div></div><h3>Available products</h3><div class="bl-store-products"><?php foreach($rows as $p): ?><article class="card bl-store-product"><div class="card-body"><span class="tag"><?php echo esc_html($p['town_name']); ?></span><h3><?php echo esc_html($p['product_name']); ?></h3><div class="price">KSh <?php echo esc_html(number_format_i18n((float)$p['price_per_unit'],2)); ?> <small>/<?php echo esc_html($p['unit']); ?></small></div><p class="meta">Available: <?php echo esc_html(number_format_i18n((float)$p['stock_quantity'],2).' '.$p['unit']); ?><br>Minimum order: <?php echo esc_html(number_format_i18n((float)$p['minimum_quantity'],2).' '.$p['unit']); ?></p><a class="bl-btn" href="<?php echo esc_url(add_query_arg(array('town_id'=>$p['town_id'],'product_id'=>$p['product_id']),home_url('/'))); ?>#orders">Order this product</a></div></article><?php endforeach; ?></div><p><a class="bl-btn secondary" href="<?php echo esc_url(home_url('/marketplace/')); ?>">← Back to marketplace</a></p></div><?php return ob_get_clean();
 }
}
