# Manual GitHub Upload — Cobriq Marketplace v2.3.0

1. Extract this ZIP on your computer.
2. Open `https://github.com/jmaina20/Cobriq-Marketplace`.
3. Choose **Add file → Upload files**.
4. Upload the contents of the extracted project folder.
5. Commit the changes to the `main` branch.

The deployable WordPress files are under `wp-content/plugins/` and `wp-content/themes/`.
