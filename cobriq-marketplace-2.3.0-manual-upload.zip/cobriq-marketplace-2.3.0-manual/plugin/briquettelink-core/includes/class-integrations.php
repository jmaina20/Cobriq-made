<?php
if (!defined('ABSPATH')) exit;
class BriquetteLink_Integrations {
 public static function init(){add_action('rest_api_init',array(__CLASS__,'routes'));add_action('briquettelink_order_created',array(__CLASS__,'notify_supplier'),10,2);add_action('briquettelink_order_status_changed',array(__CLASS__,'notify_customer'),10,3);}
 public static function routes(){register_rest_route('briquettelink/v1','/whatsapp/webhook',array(array('methods'=>'GET','callback'=>array(__CLASS__,'verify'),'permission_callback'=>'__return_true'),array('methods'=>'POST','callback'=>array(__CLASS__,'receive'),'permission_callback'=>'__return_true')));}
 public static function enabled(){return (bool)get_option('briquettelink_whatsapp_enabled',0);}
 public static function verify($r){if(!self::enabled())return new WP_Error('whatsapp_disabled','WhatsApp integration is not enabled.',array('status'=>404));$mode=$r->get_param('hub_mode');$token=$r->get_param('hub_verify_token');$challenge=$r->get_param('hub_challenge');$expected=get_option('briquettelink_whatsapp_verify_token','');if($mode==='subscribe'&&$expected&&hash_equals($expected,(string)$token))return new WP_REST_Response($challenge,200);return new WP_Error('whatsapp_verification_failed','Verification failed.',array('status'=>403));}
 public static function receive($r){if(!self::enabled())return new WP_REST_Response(array('received'=>false,'reason'=>'disabled'),404);global $wpdb;$t=BriquetteLink_Database::tables();$raw=$r->get_body();$data=json_decode($raw,true);$wpdb->insert($t['webhook_logs'],array('provider'=>'whatsapp','event_type'=>$data['entry'][0]['changes'][0]['field']??'message','payload'=>$raw,'created_at'=>current_time('mysql')));do_action('briquettelink_whatsapp_event',$data);return new WP_REST_Response(array('received'=>true),200);}
 public static function notify_supplier($order_id,$supplier_id){if(!$supplier_id)return;global $wpdb;$t=BriquetteLink_Database::tables();$o=$wpdb->get_row($wpdb->prepare("SELECT o.order_number,o.customer_name,o.customer_phone,o.total,s.email,s.business_name FROM {$t['orders']} o JOIN {$t['suppliers']} s ON s.id=o.supplier_id WHERE o.id=%d",$order_id),ARRAY_A);if($o&&is_email($o['email']))wp_mail($o['email'],'New BriquetteLink order '.$o['order_number'],"A new order has been assigned to {$o['business_name']}.\nOrder: {$o['order_number']}\nCustomer: {$o['customer_name']}\nPhone: {$o['customer_phone']}\nOrder value: KSh {$o['total']}\nLog in to your supplier portal to process it.");do_action('briquettelink_supplier_notification',$order_id,$supplier_id);}

 public static function notify_customer($order_id,$new_status,$old_status=''){
  if($new_status===$old_status)return;
  global $wpdb;$t=BriquetteLink_Database::tables();
  $o=$wpdb->get_row($wpdb->prepare("SELECT order_number,customer_name,customer_phone,customer_whatsapp,total FROM {$t['orders']} WHERE id=%d",$order_id),ARRAY_A);
  if(!$o)return;
  $message='BriquetteLink order '.$o['order_number'].' update: '.ucwords(str_replace('_',' ',$new_status)).'.';
  do_action('briquettelink_customer_notification',$o,$message);
  if(self::enabled()&&($o['customer_whatsapp']||$o['customer_phone']))self::send_text($o['customer_whatsapp']?:$o['customer_phone'],$message);
 }

 public static function send_text($to,$message){if(!self::enabled())return new WP_Error('whatsapp_disabled','WhatsApp is not enabled.');$token=get_option('briquettelink_whatsapp_access_token','');$phone_id=get_option('briquettelink_whatsapp_phone_number_id','');$version=get_option('briquettelink_whatsapp_graph_version','v23.0');if(!$token||!$phone_id)return new WP_Error('whatsapp_not_configured','WhatsApp credentials are not configured.');$url='https://graph.facebook.com/'.rawurlencode($version).'/'.rawurlencode($phone_id).'/messages';$res=wp_remote_post($url,array('timeout'=>20,'headers'=>array('Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'),'body'=>wp_json_encode(array('messaging_product'=>'whatsapp','to'=>preg_replace('/\D+/','',$to),'type'=>'text','text'=>array('body'=>$message)))));if(is_wp_error($res))return $res;return json_decode(wp_remote_retrieve_body($res),true);}
}
