<?php
/**
 * Plugin Name: BriquetteLink Core
 * Description: Kenya-wide briquette marketplace backend with town-based matching, supplier onboarding/portal, inventory, orders and optional WhatsApp integration. Payments are intentionally excluded.
 * Version: 2.3.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: BriquetteLink
 * Text Domain: briquettelink-core
 */
if (!defined('ABSPATH')) exit;
define('BRIQUETTELINK_VERSION','2.3.0');
define('BRIQUETTELINK_FILE',__FILE__);
define('BRIQUETTELINK_DIR',plugin_dir_path(__FILE__));
define('BRIQUETTELINK_URL',plugin_dir_url(__FILE__));
require_once BRIQUETTELINK_DIR.'includes/class-database.php';
require_once BRIQUETTELINK_DIR.'includes/class-matcher.php';
require_once BRIQUETTELINK_DIR.'includes/class-rest.php';
require_once BRIQUETTELINK_DIR.'includes/class-integrations.php';
require_once BRIQUETTELINK_DIR.'includes/class-portal.php';
require_once BRIQUETTELINK_DIR.'includes/class-customer.php';
require_once BRIQUETTELINK_DIR.'includes/class-marketplace.php';
require_once BRIQUETTELINK_DIR.'includes/class-admin.php';
require_once BRIQUETTELINK_DIR.'includes/class-orders-admin.php';
require_once BRIQUETTELINK_DIR.'includes/class-analytics.php';
register_activation_hook(__FILE__,array('BriquetteLink_Database','install'));
register_deactivation_hook(__FILE__,array('BriquetteLink_Portal','deactivate'));
add_action('plugins_loaded',function(){
    BriquetteLink_Database::maybe_upgrade();
    BriquetteLink_Portal::init();
    BriquetteLink_Customer::init();
    BriquetteLink_Marketplace::init();
    BriquetteLink_REST::init();
    BriquetteLink_Integrations::init();
    BriquetteLink_Admin::init();
    BriquetteLink_Orders_Admin::init();
    BriquetteLink_Analytics::init();
});
